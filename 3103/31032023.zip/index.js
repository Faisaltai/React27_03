import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import img1 from './screenshot4.png';
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  
  <>

  <h1>This is my First REACT PROJECT</h1>
   <h2 className="tops">TOPS TECHNOLOGIES</h2>
   <img src={img1} alt=""/>
   </>
);
