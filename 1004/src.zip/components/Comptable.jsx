import React from "react";
export default function Comptable(){
    return <>
    <table className="table table-hover">
        <thead>
            <tr>
                <td>Sr. No.</td>
                <td>Name</td>
                <td>Marks</td>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>1</td>
                <td>RAM</td>
                <td>100</td>
            </tr>
            <tr>
                <td>2</td>
                <td>Laxman</td>
                <td>99</td>
            </tr>
            </tbody>
        </table>
    </>
}
