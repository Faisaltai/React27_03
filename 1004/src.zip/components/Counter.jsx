import React, { useState } from 'react'

function Counter() {
    const [counter,setCounter]=useState(1);
    function increment(){
        setCounter(counter+1)
    }
    function decrement(){
        setCounter(counter-1)
    }
    
  return (
    <div>
    {counter} <br></br>
    <button className="btn btn-primary" onClick={increment}>Increment</button>
    <button className="btn btn-primary" onClick={decrement}>Decrement</button>
    </div>
  )
}

export default Counter