import React from 'react';
import ReactDOM from 'react-dom/client';
import Mycomp from './components/Mycomp';
import img1 from './components/images/myimage.jpg';
import img2 from './components/images/myimage.jpg';
import img3 from './components/images/myimage.jpg';
import img4 from './components/images/myimage.jpg';
import Counter from './components/Counter';
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <>
  <Counter/>
  {/* components with props */}
  {/* <img src="myimage.jpg" alt=""></img>
  <Mycomp name="TOPS" data="Welcome to tops" image={img1}/> 
  <Mycomp name="REACT" data="This is REACT" image={img2}/>
  <Mycomp name="NODE" data="this is NODE"image={img3}/>
  <Mycomp name="FULL STACK" data="You are a Fullstack developer"image={img4}/> */}
  </>
);
