import React from "react";

import './css/Mycomp.css'
import Comptable from "./Comptable";

function Mycomp(props) {
    return <>
        <h1>{props.name}</h1>
        <p>{props.data}</p>
        <img src={props.image} alt=""></img>
        <button className="btn btn-primary">Click Here</button>
        
        {/* component within component (nested component) */}
        <Comptable name="" marks=""/> 

    </>;
}
export default Mycomp;